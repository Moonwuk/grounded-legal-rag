# Firefox Privacy Notice

Effective May 4, 2026
{: datetime="2026-05-04" }

## At Mozilla, we believe that privacy is fundamental to a healthy internet

That’s why we build Firefox, and all our products, to give you greater control over the information you share online and the information you share with us. In this Privacy Notice, we explain what data we process, how we process it, and for what purposes. Then, we explain how you can exercise choices about how we process your information.

## How is your data used?

### To provide you with the Firefox browser

Mozilla collects [certain data](#bookmark-how-we-use-data), like technical and settings data, to provide the core functionality of the Firefox browser and associated services, distinguish your device from others, remember and respect your settings, and provide you with default features such as [New Tab](https://support.mozilla.org/kb/about-new-tab-page), [PDF editing](https://support.mozilla.org/kb/view-pdf-files-firefox-or-choose-another-viewer), [password manager](https://support.mozilla.org/kb/manage-your-logins-firefox-password-manager) and [Total Cookie Protection](https://support.mozilla.org/kb/introducing-total-cookie-protection-standard-mode). You can further customize your Firefox experience by adjusting your [controls, buttons, and toolbars](https://support.mozilla.org/kb/customize-firefox-controls-buttons-and-toolbars) and adding [features with add-ons](https://support.mozilla.org/kb/find-and-install-add-ons-add-features-to-firefox).

Some Firefox features, like automated [translation](https://support.mozilla.org/kb/website-translation) for web pages and [“alt-text” suggestions when you upload images in your PDFs](https://support.mozilla.org/kb/pdf-alt-text), are powered by artificial intelligence (AI) based on small language models downloaded to your device. These operate locally — web page content, PDFs, images and tab URLs stay on your device and are not sent to Mozilla’s servers or used for training purposes without your explicit consent. Note that other Firefox features may integrate third-party AI models, as further detailed in this Notice. Learn more, including how to [control AI-based features](https://support.mozilla.org/kb/firefox-ai-controls) and models in your settings.

If you choose to use the Smart Window feature, your use of the feature is governed by the [Smart Window Privacy Notice](https://www.mozilla.org/privacy/smart-window/), which explains how data is processed in connection with Smart Window.

### To adapt Firefox to your needs

Firefox processes a variety of personal data in a way that does not leave your device, such as browsing history, web form data, temporary internet files, and cookies. This means the data stays on your device and is not sent to Mozilla’s servers unless it says otherwise in this Notice. If you choose to allow it, your precise location may also be processed for location-related functionality for websites like Google Maps; this data is only accessed from your device by the website(s) you choose to enable it for — it is not sent to Mozilla’s servers.

If you enable the Shake to Summarize feature on a compatible device running a supported operating system that enables on-device intelligence, summaries you request will be created locally on your device. Otherwise, when you request a summary, your page content will be sent to a Mozilla server for processing and returned to your device; Mozilla does not store this content or resulting summaries. Learn more about Shake to Summarize on [iOS](https://blog.mozilla.org/en/firefox/shake-to-summarize/) and [Android](https://support.mozilla.org/kb/summarize-pages-android).

*More details, including how to adjust your data settings:* Data processed on your device remains in your control. You can [manage your browsing data](https://support.mozilla.org/kb/delete-browsing-search-download-history-firefox) and your [local storage settings](https://support.mozilla.org/kb/storage), or update your [location permissions](https://support.mozilla.org/kb/does-firefox-share-my-location-websites) at any time.

### To provide you with Firefox VPN

If you are signed in to a Mozilla account, you can enable a Firefox feature to conceal your IP address through a proxy server (“VPN”). When enabled, it proxies Firefox network traffic through an intermediary to prevent your network provider from seeing which servers you connect to and to hide your IP address from the sites you visit. It does not proxy traffic from other applications on the device, and does not, on its own, make your website browsing fully anonymous. Use of VPN may impact your browsing experience, including by serving content not specific to your region.

We use a proxy server operated on our behalf to provide the VPN feature. The proxy server does not have access to webpage content or other sensitive information, such as messages or passwords, and does not collect data about the websites you visit or the content of those sites. We do process limited technical data (such as the client version, connection status, and device type/operating system) to provide, maintain, and ensure the performance and stability of the service, as well as interaction data to understand usage of the feature and help guide improvements.

### To provide and improve search functionality and suggestions

As you type a search query within Firefox, Firefox offers [search suggestions](https://support.mozilla.org/kb/search-suggestions-firefox) to provide you with faster and more direct access to what you’re looking for. Some of the search suggestions come from your search provider (“Search Suggestions”). Others come from Firefox, and are based on information stored on your local device (including recent search terms, open tabs, and previously visited URLs), or content from Mozilla and Mozilla’s partners, including paid sponsors and internet resources like Wikipedia (“Suggestions from Firefox”).

By default, Firefox shows Search Suggestions. Suggestion requests — including your real-time search query and technical data — are sent directly to your search provider as you type, and processed according to your search provider’s privacy notice ([linked below](#bookmark-search-pns)). You can turn off Search Suggestions or change your default search provider at any time, as outlined on this [Firefox Support](https://support.mozilla.org/kb/firefox-suggest) page.

Users in the United States and certain other regions will also receive Suggestions from Firefox. You can turn these off entirely, or just turn off sponsored Suggestions from Firefox, in your browser settings.

In the United States, Firefox fetches suggestions from Mozilla’s servers as you type your query. We use a privacy preserving technology called [OHTTP](https://blog.mozilla.org/en/products/firefox/partnership-ohttp-prio/), which combines encryption and a proxy server to conceal your IP address and other identifying information. Your real-time search query, along with technical, interaction, and IP-derived location data are passed through this OHTTP proxy by default before being sent to Mozilla. This helps prevent anyone (including Mozilla) from associating your specific query with you, or from combining it with unrelated information about your browsing activity. Mozilla processes this data to serve you relevant suggestions, understand how useful the suggestions are to you, and improve the service. In some circumstances Mozilla’s partners will receive de-identified search and interaction data, in order to serve relevant suggestions and measure user engagement with suggested content.

Some users — including users in some regions outside the U.S. and U.S.-based users who deselect “retrieve Suggestions from Mozilla as you type” in their settings — will instead receive locally processed results when using the Suggestions from Firefox feature. For these users, the suggestions will be served locally, using information stored on your device, in your copy of Firefox. Your de-identified click and interaction data for specific query keywords (but not your search query) are sent to Mozilla via OHTTP to conceal your IP address and other identifying information. For sponsored suggestions, our partners may receive aggregated information about which of their suggestions are shown and clicked on, but not which users saw the suggestions or which keywords caused those suggestions to be served. (If Suggestions from Firefox are unavailable in your region, you will only receive suggestions Search Suggestions).

### To serve relevant content and advertising on Firefox New Tab

Firefox shows content on New Tab, along with advertising to support its development. You can turn these off at any time in your browser settings.

We use technical data, language preference, and IP-derived location to serve this content in the correct format (i.e. for mobile vs desktop), language, and relevant location. Mozilla collects technical and interaction data, such as the position, size, views and clicks on New Tab content or ads, to understand how people are interacting with our content and to personalize future content, including sponsored content. This data may be shared with our advertising partners on an aggregated and/or de-identified basis.

In some regions, we use this data to build models and group users based on common attributes. These groupings help us understand how people are interacting with our content and to personalize future content, including sponsored content. We use on-device processing and OHTTP to avoid revealing to Mozilla the attributes of any specific user. [Learn more](https://support.mozilla.org/kb/firefox-new-tab-personalization).

We also work with advertising providers to deliver relevant sponsored content using programmatic technologies. To support this, we may share limited, non-identifying information — such as device type, IP-derived location information, and category of content viewed — to help determine which ads to display. We don’t share any information that identifies you. You can turn off sponsored content in your New Tab settings at any time.

In some cases, when ads are enabled on New Tab, additional browsing and interaction data (including interactions with our advertisers) may also be processed locally on your device to measure the effectiveness of those ads; the [shortcuts](https://support.mozilla.org/kb/about-new-tab-page#w_shortcuts) feature also uses browsing data locally on your device to select top shortcuts, some of which may be sponsored. Any such data will only be shared with Mozilla and/or our advertising partners via our privacy-preserving technologies on an aggregated and/or de-identified basis.

When a user visits a third-party website by clicking an advertisement or link in Firefox, that site may use cookies and other web APIs available to any website to collect data subject to that website’s privacy and/or cookie notices.

You can turn off or customize any of these New Tab features along with their associated data processing in your browser settings ([Desktop](https://support.mozilla.org/kb/customize-your-new-tab-page), [Android](https://support.mozilla.org/kb/customize-firefox-home-screen), [iOS](https://support.mozilla.org/kb/customize-firefox-home-ios)). You can also [disable sponsored content](https://support.mozilla.org/kb/sponsor-privacy) while continuing to use the rest of the features.

### To provide Mozilla accounts

If you sign up for a Mozilla account, we process additional information alongside the data set out in this Notice, such as account details, contact information and sync data, in accordance with the [Mozilla Accounts Privacy Notice](https://www.mozilla.org/privacy/mozilla-accounts/).

### To provide AI chatbots

You have the option to use a third-party AI chatbot of your choice to help you with things like summarizing what you’re reading, writing, and brainstorming ideas, subject to that provider’s [terms of use and privacy notice](https://support.mozilla.org/kb/ai-chatbot#w_learn-about-chatbot-providers).

If you choose to enable a chatbot in the sidebar and/or through a shortcut, Mozilla does not have access to your conversations or the underlying content you input into the selected chatbot. We do collect technical and interaction data on how this feature is used to help improve Firefox, such as how often each third-party chatbot provider is chosen, how often suggested prompts are used, and the length of selected text.

*More details, including how to adjust your data settings:* You can read more about how to [manage or remove](https://support.mozilla.org/kb/ai-chatbot) AI chatbots in Firefox.

### To provide and enable add-ons (addons.mozilla.org)

You can install add-ons from [addons.mozilla.org](https://addons.mozilla.org) (“AMO”) or from the Firefox Add-ons Manager, which is accessible from the Firefox menu button in the toolbar. We process your search queries in the Add-ons Manager to be able to provide you with suggested add-ons. If you choose to install any add-ons, Firefox will process technical, IP-derived location, and settings data, and periodically connect with Mozilla’s servers to install and apply the correct updates to your add-ons. We also collect technical and interaction data on usage of add-ons, to help improve Firefox.

When you visit the [AMO website](https://addons.mozilla.org/firefox/), Mozilla collects technical and interaction data about your usage of the site in accordance with our [Mozilla Websites, Communications and Cookies](https://www.mozilla.org/privacy/websites/) notice.

*More details, including how to adjust your data settings:* Learn [how to remove or enable add-ons](https://support.mozilla.org/kb/disable-or-remove-add-ons). You can also review the [Privacy Notice](https://www.mozilla.org/privacy/websites/) for the [add-ons website](https://addons.mozilla.org/firefox/).

### To maintain and improve features, performance and stability

Mozilla runs [studies](https://support.mozilla.org/kb/shield) within Firefox and makes certain [experimental features](https://support.mozilla.org/kb/firefox-labs-explore-experimental-features-firefox) available through Firefox Labs to test different features and ideas before they’re made available to all Firefox users or become part of the core Firefox offering — this allows us to make more informed decisions about what our users want and need. This research uses technical, system performance, IP-derived location, settings and interaction data.

We also need to process data to keep Firefox operational, improve features and performance, and identify, troubleshoot and diagnose issues. For this we use technical, IP-derived location, and settings data, as well as interaction and system performance data (such as number of tabs open, memory usage or the outcome of automated processes like updates). In the rare situations where the information needed also includes limited browsing data (e.g., Top Level Domain annotations for page-load performance monitoring), it will be transmitted using OHTTP; this helps prevent Mozilla from linking you or your device to the data collected for this purpose.

On desktop and Android, if Firefox encounters an unexpected issue, the [Mozilla Crash Reporter](https://support.mozilla.org/kb/mozillacrashreporter) will also ask if you wish to send us additional information, which may include sites that were open at the time of the crash and other browsing data. On Desktop and Android if you opt in to sending us crash reports automatically, we collect this information without prompting you each time; on iOS, crash reports contain less information and are sent automatically to us by default. You can change your settings at any time.

*More details, including how to adjust your data settings:* You can [learn more](https://support.mozilla.org/kb/shield) about the studies you’re enrolled in and opt out of all (or a specific) studies at any time, and opt into experimental features through [Firefox Labs](https://support.mozilla.org/kb/firefox-labs-explore-experimental-features-firefox). You can also [learn more](https://support.mozilla.org/kb/technical-and-interaction-data) about the technical and interaction data we process, including how to turn it off.

### To improve security

Because maintaining the latest version of Firefox helps keep you safe against vulnerabilities, desktop versions of Firefox regularly connect to Mozilla’s servers (or another service that you used to install Firefox) to check for software updates; updates for Android and iOS versions of Firefox are managed by Google’s Play Store and Apple’s App Store, respectively.

We also process technical data and settings data to protect against malicious add-ons.
In addition to these standard processes, we use [Google’s Safe Browsing Service](https://support.mozilla.org/kb/how-does-phishing-and-malware-protection-work) to protect you from malicious downloads and phishing attacks, and validate webpage and technical data with [Certificate Authorities](https://support.mozilla.org/kb/secure-website-certificate). As part of our work to improve privacy and security for all internet users, we collect technical data via OHTTP, to better understand, prevent and defend against fingerprinting.

For [some Firefox users](https://support.mozilla.org/kb/firefox-dns-over-https), Firefox routes DNS requests to a resolver service that has agreed to Mozilla’s [strict privacy standards for resolvers](https://wiki.mozilla.org/Security/DOH-resolver-policy). This provides added protection from privacy leaks to local networks and also from certain DNS security attacks. System logs of your DNS requests are deleted from the service within 24 hours and are only used for the purpose of DNS resolution. [Learn more](https://support.mozilla.org/kb/firefox-dns-over-https#w_switching-providers) about DNS over HTTPS.

*More details, including how to adjust your data settings:* [Upgrades and add-ons blocklist](https://support.mozilla.org/kb/how-stop-firefox-making-automatic-connections), [Google’s Safe Browsing Service](https://support.mozilla.org/kb/how-does-phishing-and-malware-protection-work), [OHTTP](https://blog.mozilla.org/en/products/firefox/partnership-ohttp-prio/).

### To understand usage of Firefox

We process [data](#bookmark-understand-usage) to better understand how you engage with our services, such as how much you use Firefox, your language preference, how often you use our search tools or interact with search suggestions, how fast pages load for you and how many ads or [CAPTCHAs](https://en.wikipedia.org/wiki/CAPTCHA) you see. This allows us to measure how people access and use our services, which helps improve our business and the functionality of Firefox.

*More details, including how to adjust your data settings:* You can update your data collection settings for [Desktop](https://support.mozilla.org/kb/share-data-mozilla-help-improve-firefox) and [Mobile](https://support.mozilla.org/kb/mobile-manage-firefox-data-collection-and-privacy) at any time. Note that deselecting “Allow Firefox to send technical and interaction data to Mozilla” will not impact the [Daily Usage Ping](https://support.mozilla.org/kb/usage-ping-settings). This Daily Usage Ping solely provides us with de-identified information that a user is using Firefox; it is not tied to any other data about you and you can opt out in settings.

### To market our services

When you allow us to do so, Firefox sends Mozilla data about the website domain or specific advertising campaign (if any) that referred you to our download page to help us understand and improve our marketing efforts. Firefox also shares information with our marketing partners to measure and improve these campaigns; what information is specifically shared varies (depending on how you discovered Firefox and your operating system) but generally includes how you were referred to our download page and whether you actively use Firefox. When Firefox is pre-installed on your device, technical and interaction data (your device type and whether Firefox is used) will be sent to our marketing partners, and shared with Mozilla.

*More details, including how to adjust your data settings:* Learn more about what [Campaign Measurement data](https://support.mozilla.org/kb/desktop-attribution-privacy) is collected and shared, and how to opt out. Firefox does not share information like your browsing history, search queries, or saved passwords with marketing technology partners. Mozilla only collects the data necessary to measure and improve our marketing campaigns.

### To pseudonymize, de-identify, aggregate or anonymize data

As part of the activities outlined above, such as understanding usage of Firefox and measuring our marketing, we may create pseudonymous, de-identified, aggregated or anonymized data. We use technology that is appropriate to the circumstances, including identifier removal, OHTTP, or [DAP](https://divviup.org/about/) — these help prevent data from being linked to you. In some cases, we may share or publish aggregated and anonymized data to facilitate research or as part of the lawful business purposes outlined above (such as sharing aggregated insights with advertising partners).

### To communicate with you

Depending on your settings (and whether or not you have a Mozilla account), we may communicate with you via in-product messaging, send you communications (including marketing-related communications), ask you to participate in research / surveys, or respond to customer support communications. You may also reach out to us directly, such as to [report a broken site within Firefox](https://support.mozilla.org/kb/report-breakage-due-blocking#w_what-information-does-mozilla-collect-from-your-report). When you communicate with us via these methods, we will only use the information you share for the purpose you provided it. We also process interaction data related to these communications to better understand who has received our service-related announcements (such as new features, updates or security alerts).

When you visit Mozilla’s help pages in connection with Firefox, Mozilla collects technical and interaction data about your usage of our websites in accordance with our [Mozilla Websites, Communications and Cookies](https://www.mozilla.org/privacy/websites/) notice to enable us to understand your usage of our support and help pages and improve them.

### To comply with applicable laws, and identify and prevent harmful, unauthorized or illegal activity

We may also be required to process your personal data to comply with applicable laws and protection purposes, such as:

* Responding to lawful requests and complying with [legal processes](https://www.mozilla.org/about/policy/transparency/), such as responding to subpoenas, investigations, or requests from government authorities. Mozilla requires a valid Legal Process to compel the disclosure of specific user data to a government.
* Responding to requests to exercise privacy rights, such as your right to access or delete your personal data.
* Identifying, investigating and addressing potential fraudulent activities, or other harmful activities such as illegal activities, cyberattacks or intellectual property infringement (including filing or defending legal claims).
* Performing internal compliance and security activities, such as audits and enterprise security management.

## How we share your personal data

To provide our services as described above, we may disclose personal data to:

|  |  |
| ----- | ----- |
| Partners, service providers, suppliers and contractors | To perform the purposes listed above, we work with partners, service providers, suppliers and contractors. We have contractual protections in place, so that the entities receiving personal data are contractually obligated to handle the data in accordance with Mozilla’s instructions. [Learn more](https://support.mozilla.org/kb/firefox-subprocessor-list). |
| Authorities | Mozilla requires a valid Legal Process to compel the disclosure of specific user data to a government. In those instances we may need to disclose the personal data set out in this Notice to law enforcement, government authorities, or similar entities to comply with applicable laws, and to identify and prevent harmful, unauthorized or illegal activity. |
| Researchers | When we are fulfilling our [mission](https://www.mozilla.org/about/manifesto/) of being open. We sometimes release information to make our products better and foster an open web, but when we do, we will do so in a de-identified and/or aggregated [format](https://wiki.mozilla.org/Data_Publishing). |
| Mozilla controlled entities and successors | As a global company, we share data across Mozilla-controlled affiliates and subsidiaries. We may also need to disclose personal data as part of a corporate transaction, such as a merger, acquisition, sale of assets or similar transaction. |

## International transfers of data

Mozilla (and our servers) are based in the United States. Because we are a global company, in order to provide the services outlined in this Privacy Notice, the information we collect may be accessed from locations where our people are located and data may also be transferred to other jurisdictions as a result of sharing data with our partners. Where applicable, we ensure we have appropriate mechanisms in place (such as [standard contractual clauses](https://commission.europa.eu/law/law-topic/data-protection/international-dimension-data-protection/standard-contractual-clauses-scc_en#eu-standard-contractual-clauses) approved by the European Commission and other relevant authorities) to protect your personal data. You can contact [dpo@mozilla.com](mailto:dpo@mozilla.com) for information on the safeguards implemented for international transfers, or for copies of the relevant standard contractual clauses.

## How long we keep your data

We only retain your personal data for as long as necessary to fulfill the purposes outlined in this Privacy Notice. In general, we do not retain personal data for more than 25 months, but actual retention periods may vary depending on the type of data and the purpose(s) for which it was collected (for example, we retain your “first seen” date for the period of your use of Firefox, so we know how long you’ve been a Firefox user). Specific retention periods may also depend on the sensitivity of the data, the context of its collection, your settings and preferences, and our legal or contractual obligations to retain or delete your data, such as for fraud prevention, regulatory compliance, or service continuity. Once the retention period expires we securely delete your data, unless otherwise required by law.

Our services also use encrypted backup storage as another layer of protection to help recover from potential disasters; data in these environments is put beyond use and only processed for business continuity purposes. We may also retain data for extended periods of time on a de-identified or aggregated basis.

## Your rights and choices

### Your rights

As a Firefox user, you have the right to:

1. Be informed about what data we process about you, why and who it’s shared with (that’s this Notice!)
2. Request a copy of the data we have about you
3. Request portability of your data
4. Request correction of any data we hold about you that is inaccurate or incomplete
5. Have personal data we hold about you deleted (in certain circumstances)
6. In some cases, restrict or object to how we use your personal data
7. Complain to your relevant data protection authority if you have concerns about how we’re handling your personal data. We’d prefer it if you contact us first (via [dpo@mozilla.com](mailto:dpo@mozilla.com)), but you can also reach out to your relevant [EU data protection authority](https://www.edpb.europa.eu/about-edpb/about-edpb/members_en), or search for (and contact) your local data protection authority

To make any of the above requests regarding your personal data, please contact us (Mozilla Corporation) through our [Data Subject Access Request Portal](https://privacyportal.onetrust.com/webform/1350748f-7139-405c-8188-22740b3b5587/4ba08202-2ede-4934-a89e-f0b0870f95f0); we will never discriminate against anyone for exercising their privacy rights. If you have any other questions regarding personal data or our privacy practices, please contact us at [compliance@mozilla.com](mailto:compliance@mozilla.com).

If you’re in the UK or EEA, you can also contact our Data Protection Officer at [dpo@mozilla.com](mailto:dpo@mozilla.com), or by mail at:

Bird & Bird DPO Services SRL<br/>
Avenue Louise 235 b 1<br/>
1050 Brussels<br/>
Belgium<br/>

We respond to all requests we receive from individuals wishing to exercise their data protection rights in accordance with applicable data protection laws, and we may need to ask you for additional information to confirm your identity before we can proceed with your request.

Please note that, when you request deletion of your Firefox data, it will be deleted within 30 days of the request (with the exception of Interaction Data, which has a standard retention period of 90 days and is automatically deleted at the end of this period).

### Your choices

You can update your data collection settings for [Desktop](https://support.mozilla.org/kb/manage-firefox-data-collection-privacy-settings) and [Mobile](https://support.mozilla.org/kb/mobile-manage-firefox-data-collection-and-privacy) at any time.

Firefox also provides [Global Privacy Control](https://support.mozilla.org/kb/global-privacy-control) (GPC), which you can enable to automatically notify websites not to sell or share information about your browsing session on that website. GPC operates as a “Do Not Sell” mechanism in some US states such as California, Colorado and Connecticut. It may also be used to indicate an opt-out of targeted advertising or general request to limit the sale or sharing of your personal data in those jurisdictions, as well as in jurisdictions such as the EU, UK, Nevada, Utah and Virginia.

## Applicability (Firefox version)

This Privacy Notice is for the most recent general release version of Firefox distributed by Mozilla. If you obtain Firefox elsewhere, or are running an older version, your copy of Firefox may contain different privacy characteristics.

Mozilla’s pre-release versions of Firefox (which are distributed through channels such as Nightly, Beta, Developer Edition and TestFlight) are development platforms frequently updated with experimental features and studies. In addition to the data collection described in this Privacy Notice, these versions by default may send certain types of web activity and crash data to Mozilla (and in some cases to our partners).

## Changes

We may need to change this policy and our notices, in which case the updates will be posted online and we will update the effective date of this notice. If the changes are substantive, we will also announce the update more prominently through Mozilla’s usual channels for such announcements, such as blog posts and forums.

## Data definitions

| Data Type | Description | Examples for Firefox users |
| ----- | ----- | ----- |
| Technical data | This is information about the hardware you are accessing our services from (such as your desktop computer, smartphone or tablet), its configurations and its connection to Firefox. | Device type, operating system, IP address, ISP (Internet Service Provider). |
| Settings | These are your preferences or settings as to how the services are provided, such as your privacy preferences or toolbar settings. If you have not made any specific choices, these will be the default settings. | Enhanced Tracking Protection settings, cookie settings, permissions (location, camera, microphone), toolbar customization. |
| Location | We infer your location from your IP address at the level of your country, city, or region. | Country code, city. |
| Precise location | Your precise location (within a few feet or meters) | Precise location. |
| Language preference | Your inferred or preferred language (if you provide it in settings) for interacting with our services. | Language. |
| Unique identifiers | These are unique identifiers, which may be created at various times to manage your interactions with the service. | Client_id, session_id, cookie identifiers. |
| System performance data | This is data about how the services are operating on your device. | Memory usage, page rendering speed. |
| Interaction data | This is data about how you engage with our services, such as how many tabs you have open or what you’ve clicked on. | Click counts, impression data, attribution data, how many searches performed, time on page, ad and sponsored tile clicks. |
| Browsing data | This is information about websites and URLs you’ve visited. This could include categories of browsing data (travel, shopping, social media), top level domains (example.com) or specific web pages visited. | Browsing category, Top Level Domains (TLDs), specific URLs. |
| Search data | This is data about the search category, search keywords or search query of terms searched for. | Search category (Food, Travel), keywords (“Boston”), search term (“current weather in Boston”). |
| Content | When you provide it to us, we may process data such as uploaded images or survey responses. | Uploaded image, bookmarks, comments, survey responses. |
| Contact data | When you provide it to us, we may process data about how to contact you. | Email address, phone number. |

## Lawful bases

<table>
    <thead>
        <tr>
            <th>What we use your data for</th>
            <th>What data we process</th>
            <th>Our lawful basis</th>
            <th>More information, including choosing how you want to share this data in Firefox</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><a id="bookmark-how-we-use-data"></a>To provide you with the Firefox browser</td>
            <td>
                <ul>
                    <li>Technical data</li>
                    <li>Location</li>
                    <li>Language preference</li>
                    <li>Settings data</li>
                    <li>Unique identifiers</li>
                    <li>Interaction data</li>
                </ul>
            </td>
            <td>
                <p><strong>Contract</strong> to provide you with the necessary functionality for Firefox to operate.</p>
                <p><strong>Legitimate interest</strong> in providing additional functionality, accessibility services and a more personalized experience.</p>
            </td>
            <td>You can also learn more about <a href="https://support.mozilla.org/kb/website-translation">translation</a> and <a href="https://support.mozilla.org/kb/pdf-alt-text">adding alt-text to images in PDFs</a>.</td>
        </tr>
        <tr>
            <td>To adapt Firefox to your needs</td>
            <td>
                <ul>
                    <li>Any data type</li>
                </ul>
            </td>
            <td>
                <p><strong>Legitimate interest</strong> in making the data on your device work for you.</p>
            </td>
            <td>Data processed on your device remains in your control. You can manage your <a href="https://support.mozilla.org/kb/storage">local storage settings</a> or <a href="https://support.mozilla.org/kb/delete-browsing-search-download-history-firefox">clear your browsing history</a> at any time.</td>
        </tr>
        <tr>
            <td>To provide and improve search functionality</td>
            <td>
                <ul>
                    <li>Technical data</li>
                    <li>Location</li>
                    <li>Language preference</li>
                    <li>Settings data</li>
                    <li>Unique identifiers</li>
                    <li>System performance data</li>
                    <li>Interaction data</li>
                    <li>Search data</li>
                </ul>
            </td>
            <td>
                <p><strong>Legitimate interest</strong> in providing and improving search functionality, as well as a more personalized search experience and sponsored results.</p>
            </td>
            <td>You can update your <a href="https://support.mozilla.org/kb/change-your-default-search-settings-firefox">Search settings</a> and <a href="https://support.mozilla.org/kb/search-suggestions-firefox">Search suggestion features</a>, at any time, and learn more about how we <a href="https://blog.mozilla.org/en/products/firefox/firefox-search-update/">categorize searches</a>.</td>
        </tr>
        <tr>
            <td>To serve relevant content and advertising on Firefox New Tab</td>
            <td>
                <ul>
                    <li>Technical data</li>
                    <li>Location</li>
                    <li>Language preference</li>
                    <li>Settings data</li>
                    <li>Unique identifiers</li>
                    <li>System performance data</li>
                    <li>Interaction data</li>
                    <li>Search data</li>
                    <li>Browsing data</li>
                </ul>
            </td>
            <td><strong>Legitimate interest</strong> in providing you content that you’re interested in and making sure that the ads you see are relevant (which supports our ability to provide our products and services).</td>
            <td>You can read more information about <a href="https://support.mozilla.org/kb/customize-your-new-tab-page">how to manage your New Tab page</a> including your <a href="https://support.mozilla.org/kb/sponsor-privacy">data settings</a>. You can opt out of having your data processed for personalization or advertising purposes by turning off personalization and/or sponsored content at any time.</td>
        </tr>
        <tr>
            <td>To provide Mozilla accounts</td>
            <td colspan="3">See our <a href="https://www.mozilla.org/privacy/mozilla-accounts/">Mozilla Accounts Privacy Notice</a></td>
        </tr>
        <tr>
            <td>To provide AI chatbots</td>
            <td>
                <ul>
                    <li>Technical data</li>
                    <li>Location</li>
                    <li>Settings data</li>
                    <li>Unique identifiers</li>
                    <li>Interaction data</li>
                </ul>
            </td>
            <td><strong>Consent</strong>, when you choose to enable an AI chatbot.</td>
            <td>You can read more about how to <a href="https://support.mozilla.org/kb/ai-chatbot">manage</a> or <a href="https://support.mozilla.org/kb/ai-chatbot#w_how-to-remove-the-ai-chatbot-shortcut-from-your-firefox-sidebar">remove</a> AI chatbots in Firefox.</td>
        </tr>
        <tr>
            <td>To enable add-ons (addons.mozilla.org, “AMO”), including offering personalized suggestions</td>
            <td>
                <ul>
                    <li>Technical data</li>
                    <li>Location</li>
                    <li>Settings data</li>
                    <li>Unique identifiers</li>
                    <li>Interaction data</li>
                    <li>Search data</li>
                </ul>
            </td>
            <td>
                <p><strong>Legitimate interest</strong> in providing and understanding usage of the AMO infrastructure, including reviewing add-ons and blocking those known to cause security, stability or performance issues.</p>
                <p><strong>Consent</strong>, when you choose to enable a specific Mozilla provided add-on. Data processed by each add-on is governed by their own Privacy Policy.</p>
            </td>
            <td>
                <p>Learn <a href="https://support.mozilla.org/kb/find-and-install-add-ons-add-features-to-firefox">how to remove or enable add-ons</a>.</p>
                <p>You can also review the <a href="https://www.mozilla.org/privacy/websites/">Privacy Notice</a> for the <a href="https://addons.mozilla.org/firefox/">add-ons website</a>.</p>
            </td>
        </tr>
        <tr>
            <td>To maintain and improve features, performance and stability</td>
            <td>
                <ul>
                    <li>Technical data</li>
                    <li>Location</li>
                    <li>Settings data</li>
                    <li>Unique identifiers</li>
                    <li>System performance data</li>
                    <li>Interaction data</li>
                    <li>Browsing data</li>
                </ul>
            </td>
            <td>
                <p><strong>Contract</strong> to ensure that Firefox remains operational.</p>
                <p><strong>Legitimate interest</strong> in performing research and measures to improve features, performance and stability.</p>
                <p><strong>Consent</strong> when you choose to send us crash reports, which may include browsing data.</p>
            </td>
            <td>You can <a href="https://support.mozilla.org/kb/shield">learn more</a> about the studies you’re enrolled in and opt out of all (or a specific) studies at any time, and opt into experimental features through <a href="https://support.mozilla.org/kb/firefox-labs-explore-experimental-features-firefox">Firefox Labs</a>.</td>
        </tr>
        <tr>
            <td>To improve security</td>
            <td>
                <ul>
                    <li>Technical data</li>
                    <li>Location</li>
                    <li>Settings data</li>
                    <li>Unique identifiers</li>
                    <li>System performance data</li>
                    <li>Browsing data (for DNS over HTTPs only)</li>
                </ul>
            </td>
            <td>
                <p><strong>Compliance with law</strong> in securing personal data as required under applicable privacy and cybersecurity regulations.</p>
                <p><strong>Legitimate interest</strong> in providing additional security measures for all our users and enhancing the overall security of the internet (such as our anti-fingerprinting work).</p>
            </td>
            <td>You can learn more about the <a href="https://support.mozilla.org/kb/how-stop-firefox-making-automatic-connections">Upgrades and add-ons blocklist</a>, <a href="https://support.mozilla.org/kb/how-does-phishing-and-malware-protection-work">Google’s Safe Browsing Service</a>, <a href="https://blog.mozilla.org/en/products/firefox/partnership-ohttp-prio/">OHTTP</a>.</td>
        </tr>
        <tr>
            <td><a id="bookmark-understand-usage"></a>To understand usage of Firefox</td>
            <td>
                <ul>
                    <li>Technical data</li>
                    <li>Location</li>
                    <li>Settings data</li>
                    <li>Unique identifiers</li>
                    <li>Interaction data</li>
                    <li>Content data</li>
                    <li>System performance data</li>
                    <li>Language preference</li>
                </ul>
            </td>
            <td>
                <p><strong>Legitimate interest</strong> in understanding how Firefox is used, enabling improvements and performing business functions such as usage reporting and forecasting.</p>
                <p><strong>Consent</strong>, where required under applicable law (e.g. when non-essential cookies are used), or where users engage with surveys or voluntarily submit other information.</p>
            </td>
            <td>You can read more detailed information about the information we collect for <a href="https://firefox-source-docs.mozilla.org/toolkit/components/telemetry/telemetry/index.html">Desktop</a>, <a href="https://dictionary.telemetry.mozilla.org/apps/fenix">Android</a> or <a href="https://dictionary.telemetry.mozilla.org/apps/firefox_ios">iOS</a>. You can update your data collection settings for <a href="https://support.mozilla.org/kb/share-data-mozilla-help-improve-firefox">Desktop</a> and <a href="https://support.mozilla.org/kb/mobile-manage-firefox-data-collection-and-privacy">Mobile</a> at any time (note that deselecting “Allow Firefox to send technical and interaction data to Mozilla” will not impact the <a href="https://support.mozilla.org/kb/usage-ping-settings">Daily Usage Ping</a>). This Daily Usage Ping solely provides us with de-identified information that a user is using Firefox; it is not tied to any other data about you and you can opt out in settings.</td>
        </tr>
        <tr>
            <td>To market our services</td>
            <td>
                <ul>
                    <li>Technical data</li>
                    <li>Location</li>
                    <li>Language preference</li>
                    <li>Settings data</li>
                    <li>Unique identifiers</li>
                    <li>Interaction data</li>
                    <li>Browsing data</li>
                    <li>System performance data</li>
                </ul>
            </td>
            <td>
                <p><strong>Legitimate interest</strong> in promoting our products and services, including sending marketing communications and measuring and improving our marketing campaigns.</p>
                <p><strong>Consent</strong>, where required under applicable law (e.g. jurisdictions which require consent to receive marketing communications).</p>
            </td>
            <td>Learn more about what <a href="https://support.mozilla.org/kb/marketing-data">Campaign Measurement data</a> is collected and shared, and how to opt out. Note: Firefox does not share information like your browsing history, search queries, or saved passwords with marketing technology partners. Mozilla only collects the data necessary to measure and improve our marketing campaigns.</td>
        </tr>
        <tr>
            <td>To pseudonymize, de-identify, aggregate or anonymize data</td>
            <td>
                <ul>
                    <li>All data types</li>
                </ul>
            </td>
            <td><strong>Legitimate interest</strong> in taking privacy-enhancing measures prior to performing analytics or sharing data with partners.</td>
            <td></td>
        </tr>
        <tr>
            <td>To communicate with you</td>
            <td>
                <ul>
                    <li>Unique identifiers</li>
                    <li>Interaction data</li>
                    <li>Contact data</li>
                    <li>Content data</li>
                    <li>Language preference</li>
                </ul>
            </td>
            <td><strong>Legitimate interest</strong> in letting you know about improvements or changes to our products or services, as well as reviewing and responding to questions or other requests.</td>
            <td></td>
        </tr>
        <tr>
            <td>To comply with applicable laws, and identify and prevent harmful, unauthorized or illegal activity</td>
            <td>
                <ul>
                    <li>All data types</li>
                </ul>
            </td>
            <td>
                <p><strong>Compliance with law</strong> in responding to data subject rights requests, responding to law enforcement requests, managing and protecting our (and our users) rights, property and/or safety.</p>
                <p><strong>Legitimate interest</strong>, where not strictly required by law, to support legal or regulatory processes or requests, prevent fraud, and manage and protect our (and our users’) rights, property and/or safety.</p>
            </td>
            <td>Learn more about how we respond to <a href="https://www.mozilla.org/about/policy/transparency/">lawful requests</a>.</td>
        </tr>
    </tbody>
</table>

<a id="bookmark-search-pns"></a>
## Privacy notices for select search providers

[Google](https://policies.google.com/privacy)

[Microsoft (Bing)](https://www.microsoft.com/privacy/privacystatement#mainsearchaimodule)

[DuckDuckGo](https://duckduckgo.com/privacy)

[Amazon.com](https://www.amazon.com/gp/help/customer/display.html?nodeId=GX7NJQ4ZB8MHFRNJ)

[eBay.com](https://www.ebay.com/help/policies/member-behaviour-policies/user-privacy-notice-privacy-policy?id=4260)

[Wikipedia](https://foundation.wikimedia.org/wiki/Policy:Privacy_policy)

[Perplexity](https://www.perplexity.ai/hub/legal/privacy-policy)
