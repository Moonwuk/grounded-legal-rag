# Termini di utilizzo di Firefox

In vigore dal 16 settembre 2026
{: datetime="2026-09-16" }

Firefox è un browser web gratuito e open source, creato da una comunità di migliaia di persone di tutto il mondo.

Ti preghiamo di leggere attentamente i seguenti Termini di utilizzo (“Termini”) in quanto contengono importanti informazioni sull'utilizzo della tua copia del software Firefox. I presenti Termini costituiscono un accordo vincolante tra te e Mozilla Corporation (“Mozilla”). Per maggiori informazioni sulle prassi di Firefox in materia di privacy, consulta l'[Informativa sulla privacy di Firefox](https://www.mozilla.org/privacy/firefox/#notice).

## Diritti e autorizzazioni che Mozilla concede a te

Mozilla ti concede una licenza personale e non esclusiva per l'installazione e l'uso della versione “Codice eseguibile” del browser web Firefox, ovvero la versione di Firefox pronta per l'esecuzione, proveniente da una fonte autorizzata, che puoi aprire e utilizzare subito.

### Firefox è un software open source

Mettiamo a tua disposizione il codice sorgente di Firefox in base ai termini di varie licenze open source, tra cui la [Mozilla Public License](https://www.mozilla.org/MPL/). Ciò significa che puoi utilizzare, copiare, modificare e distribuire Firefox a terzi, a condizione che tu rispetti le licenze open source e le indicazioni contenute nelle [Mozilla Trademark Guidelines](https://www.mozilla.org/foundation/trademarks/policy/). I presenti Termini si applicano solo alla versione Codice eseguibile di Firefox e non al codice sorgente di Firefox.

Per riprodurre alcuni tipi di video, Firefox può scaricare da terze parti moduli di decodifica dei contenuti che potrebbero non essere open source.

### Proprietà intellettuale di Mozilla

Mozilla non ti concede alcun diritto di proprietà intellettuale su Firefox non specificamente indicato nei presenti Termini. Ad esempio, i presenti Termini non ti concedono il diritto di utilizzare copyright, marchi commerciali o altre caratteristiche distintive del brand Mozilla o dei suoi licenziatari.

## Diritti e autorizzazioni che tu concedi a Mozilla

Concedi a Mozilla i diritti necessari al funzionamento di Firefox. Ciò include il trattamento dei tuoi dati come descritto nell'[Informativa sulla privacy di Firefox](https://www.mozilla.org/privacy/firefox/#notice).

### Feedback e suggerimenti

Se offri a Mozilla idee, suggerimenti o feedback sui Servizi, fornisci a Mozilla il permesso di usarli gratuitamente e senza ulteriori obblighi.

## Se utilizzi alcune funzioni o servizi opzionali di Firefox, sono previsti dei termini aggiuntivi

### Alcuni servizi di Firefox richiedono un account Mozilla

Per utilizzare alcuni servizi, come la sincronizzazione, è necessario un account Mozilla. Per creare un account Mozilla, devi accettare i [Termini di servizio](https://www.mozilla.org/about/legal/terms/services/) e l'[Informativa sulla privacy](https://www.mozilla.org/privacy/mozilla-accounts/) degli account Mozilla.

### Altri servizi opzionali

Alcune funzioni di Firefox richiedono il tuo consenso specifico. Per poterle utilizzare, dovrai accettare i Termini di utilizzo e l'Informativa sulla privacy specifici di ogni servizio utilizzato.

## Mozilla può aggiornare o rescindere il presente Accordo

### Mozilla può aggiornare i presenti Termini

Di tanto in tanto, Mozilla può decidere di aggiornare i presenti Termini. I Termini aggiornati verranno pubblicati online. L'uso continuato di Firefox implicherà l'accettazione di tali modifiche. All'inizio di questa pagina verrà pubblicata la data di entrata in vigore dei Termini, in modo che sia possibile identificare chiaramente l'aggiornamento più recente.

### Risoluzione

I presenti Termini sono applicabili finché tu o Mozilla non deciderete di revocarli. Puoi scegliere di interromperne la validità in qualsiasi momento e per qualsiasi ragione, smettendo di utilizzare Firefox. Mozilla può sospendere o revocare l'accesso di qualunque utente a Firefox in qualsiasi momento e per qualunque ragione, inclusa l'eventuale decisione di Mozilla di cessare la fornitura di Firefox. Se dovessimo decidere di sospendere o revocare il tuo accesso, cercheremo di avvisarti utilizzando l'indirizzo email associato al tuo account o al tuo successivo tentativo di accesso all'account.

## Le conseguenze del tuo utilizzo di Firefox ricadono unicamente su di te

Accetti di non utilizzare Firefox per violare i diritti altrui o per violare le leggi o i regolamenti vigenti.

Accetti inoltre di non impegnarti in attività che interferiscano con i servizi e i prodotti di Mozilla o ne interrompano il funzionamento o l'efficacia (o quella dei server e delle reti connesse ai servizi di Mozilla).

## Dichiari di non ritenere Mozilla responsabile per il tuo uso di Firefox (indennizzo)

**Accetti di manlevare e considerare Mozilla e le sue affiliate sollevate da qualsiasi responsabilità o rivendicazione derivante dal tuo utilizzo di Firefox, nella misura consentita dalle leggi vigenti.**

## Importanti limitazioni della responsabilità di Mozilla

**Nei limiti permessi dalla legge, accetti che Mozilla non venga ritenuta in alcun modo responsabile per l'eventuale impossibilità di utilizzare Firefox o per sue eventuali limitazioni. Nello specifico, Mozilla non sarà ritenuta responsabile per quanto segue: danni indiretti speciali, incidentali, conseguenti o esemplari, nonché danni diretti o indiretti per perdita di avviamento, interruzione di attività, perdita di profitti, perdita di dati, guasto o malfunzionamento di computer. Qualunque responsabilità di Mozilla, ai sensi del presente accordo, è limitata a $500.**

La legislazione vigente nel tuo Paese potrebbe concederti ulteriori diritti. Nulla nei presenti Termini intende compromettere tali diritti, se applicabili.

## Firefox viene fornito “così com'è” (Esclusione di garanzia)

**Mozilla fornisce i Servizi “così come sono”. Nei limiti consentiti dalla legge applicabile, Mozilla e le sue affiliate declinano specificamente qualsiasi garanzia giuridica e, in particolare, disconoscono eventuali garanzie implicite di “commerciabilità”, “idoneità a un uso specifico”, “non violazione”, così come qualsiasi garanzia derivante da accordi, dall'uso o dalla pratica.**

## Cose da sapere

### Legge applicabile

Il presente contratto è regolamentato dalle leggi dello stato della California, U.S.A., ad esclusione delle disposizioni sul conflitto di leggi della California.

In caso di incoerenza tra la versione in lingua inglese dei presenti Termini e la versione tradotta, avrà priorità la versione in lingua inglese.

### Puoi contattare Mozilla al seguente indirizzo:

Mozilla Corporation <br>
Att.: Mozilla – Legal Notices <br>
1875 Mission Street, Suite 103 <br>
San Francisco, CA 94103

legal-notices@mozilla.com

Si precisa che non accettiamo richieste di informazioni da parte di enti governativi all'indirizzo sopra indicato. Per informazioni su come inviare tali richieste, consulta la nostra [pagina della trasparenza](https://www.mozilla.org/about/policy/transparency/).
