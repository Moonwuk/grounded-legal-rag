# Conditions d’utilisation de Common Voice 

Date d'effet : vendredi 31 octobre 2025 {: datetime="2025-10-31" }

À compter de la date de « dernière mise à jour » indiquée ci-dessus, les informations et les ensembles de données que nous mettons à disposition via Common Voice seront désormais accessibles via Mozilla Data Collective (« MDC »). 

Vous ne pourrez participer au projet Common Voice que si vous acceptez les présentes conditions juridiques Common Voice (« Conditions »). 

Vous ne pourrez participer au projet Common Voice que si vous acceptez les présentes conditions juridiques Common Voice (« Conditions »). Votre utilisation de Mozilla Common Voice est régie par les présentes Conditions d'utilisation et la [Politique de confidentialité de Common Voice](https://commonvoice.mozilla.org/privacy).

## 1. Éligibilité

Common Voice est accessible à toute personne âgée de plus de 19 ans. Si vous avez 19 ans ou moins, vous devez avoir le consentement d’un de vos parents ou de votre tuteur, qui doit superviser votre participation à Common Voice. 

Common Voice fait partie de la communauté de Mozilla. Par conséquent, si vous décidez d’y prendre part, vous acceptez de vous conformer aux [Directives relatives à la participation communautaire de Mozilla](https://www.mozilla.org/about/governance/policies/participation/). 

## 2. Vos Contributions

Nous mettons à disposition le jeu de données Common Voice de Mozilla conformément à la [Creative Commons CC0 Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/). Cela signifie qu'il est public et que nous avons renoncé à tous les droits d'auteur dans les limites autorisées par la loi. Si vous participez à Common Voice, nous vous demandons d'en faire de même. Vous acceptez que Mozilla puisse proposer toutes les Contributions que vous mettez à disposition de Common Voice, notamment les textes, enregistrements et commentaires (les « Contributions ») au public conformément à la [CC0](https://creativecommons.org/publicdomain/zero/1.0/) Public Domain Dedication. 

Pour pouvoir participer à Common Voice, Mozilla vous demande également de confirmer trois points : 

Tout d’abord, vos Contributions doivent entièrement être de votre propre création.

Enfin, vos Contributions ne doivent pas enfreindre les droits d’une quelconque tierce partie. 

Troisièmement, que vos contributions soient conformes à la [Politique d'utilisation acceptable](https://www.mozilla.org/about/legal/acceptable-use/) de Mozilla.

Si vous ne pouvez pas garantir ces deux points, vous ne pouvez pas participer à Common Voice. 

De plus, si vous participez au projet Common Voices Spontaneous Speech, vous acceptez de ne pas inclure dans les enregistrements que vous soumettez des données sensibles ou personnelles vous concernant ou concernant des tiers. 

Enfin, Mozilla met les ensembles de données Common Voice à la disposition du grand public exclusivement par l'intermédiaire de MDC sous une licence Creative Common Zero (CC0), sauf indication contraire. Conformément à nos principes de gestion des données, nous vous demandons de ne pas publier, distribuer ou reproduire tout ou partie des ensembles de données Common Voice sur d'autres plateformes ou services, et de ne permettre l'accès à ces données à des tiers que par l'intermédiaire du MDC.

## 3. Votre compte

Vous n’avez pas besoin de créer un compte pour participer à Common Voice. 

Pour participer à certaines fonctionnalités supplémentaires de Common Voice (comme des soumissions de petites phrases ou de lots de phrases, la revue de phrases ou l'ajout et la transcription d'invites), vous devrez créer un compte Mozilla. Vous pouvez créer un compte Mozilla [ici](https://commonvoice.mozilla.org/login). Votre utilisation de comptes Mozilla est régie par les [Conditions d'utilisation des comptes Mozilla](https://www.mozilla.org/about/legal/terms/services/) et la [Politique de confidentialité des comptes Mozilla](https://www.mozilla.org/privacy/mozilla-accounts/). Si vous créez un compte, Mozilla vous demandera votre adresse e-mail et un nom d'utilisateur (de votre choix). Vous pouvez également fournir un avatar et certaines informations d'ordre démographique via la plateforme Common Voice. Les informations démographiques nous aident, ainsi que d'autres chercheurs, à améliorer et créer une technologie et des outils concernant la parole.

Si vous participez au test Alpha ou Bêta du projet Common Voice Spontaneous Speech, vous devez nous communiquer votre adresse e-mail afin que nous puissions vous envoyer un lien pour vous connecter et participer au projet Common Voice Spontaneous Speech. 

Si vous fournissez des informations pour votre compte en relation avec Common Voice, vous octroyez à Mozilla toutes les permissions nécessaires pour effectuer ce qui suit : suivre les informations relatives à vos Contributions, associer ces Contributions à votre compte, adresse e-mail, nom d'utilisateur et les informations démographiques que vous fournissez, publier publiquement vos Contributions ainsi que toutes informations démographiques, et publier des mesures relatives à vos Contributions (comme le nombre d'enregistrements et les langues), ainsi que votre nom d'utilisateur dans le classement.  

Mozilla ne mettra pas en ligne ni ne publiera, de façon publiquement accessible, votre adresse électronique. 

Vous pouvez choisir de ne pas apparaître dans les classements. Le cas échéant, Mozilla ne publiera aucune donnée relative à vos enregistrements et associée à votre nom d’utilisateur. Cependant, dans le cadre de Common Voice, Mozilla rendra vos textes et enregistrements accessibles au public et intégrera des informations concernant vos enregistrements dans les indicateurs globaux qui sont publiquement accessibles.

## 4. Communications.

Si vous vous inscrivez pour recevoir nos bulletins d'information ou ouvrir un compte en rapport avec Common Voice, nous sommes susceptibles de vous envoyer des e-mails en rapport avec votre compte. 

## 5. Avis de non-responsabilité.

En participant à Common Voice, vous reconnaissez que Mozilla ne sera en aucun cas responsable de toute impossibilité d’utiliser Common Voice ou de toute réclamation découlant des présentes conditions. Mozilla décline expressément ce qui suit :

Dommages indirects, particuliers, accessoires, consécutifs ou exemplaires, incluant sans s'y limiter les dommages directs et indirects de perte de clientèle, arrêts de travail, perte de profits, perte de données ou mauvais fonctionnement d’ordinateur.

Le montant de la responsabilité de Mozilla est limité à $500. 

Vous acceptez d’indemniser et de tenir Mozilla à l’écart de toute responsabilité ou réclamation suite à votre participation au projet Common Voice. 

Mozilla fournit Common Voice « tel quel ». Mozilla décline spécifiquement toutes garanties telles que « qualité marchande », « adéquation à une fin particulière », « violation de droits » et les garanties liées aux transactions, à l’usage ou au commerce. 

## 6. Avis de violation

Si vous pensez qu’un élément de Common Voice porte atteinte à vos droits d’auteur ou à vos droits de marque, veuillez consulter notre [politique de signalement d’une violation](https://www.mozilla.org/about/legal/report-infringement/).

## 7. Mises à jour

De temps à autre, Mozilla peut décider de mettre à jour les présentes Conditions. Les nouvelles Conditions seront publiées en ligne. 

Si vous continuez à utiliser Common Voice après la publication de ces nouvelles Conditions, vous convenez que cela vaut acceptation des modifications apportées. Nous afficherons une date d’entrée en vigueur en haut de la page afin d’indiquer clairement la date de notre dernière mise à jour. 

## 8. Résiliation

Mozilla peut suspendre ou mettre fin à l’accès à Common Voice de toute personne, pour toute raison et à tout moment. Si nous décidons de suspendre votre accès ou d’y mettre fin, nous essaierons de vous notifier notre décision via l’adresse e-mail associée à votre compte ou lors du prochain accès à Common Voice. 

Les Contributions que vous soumettez à Mozilla resteront à la disposition du public dans le cadre de Common Voice, même si nous résilions votre accès. 

## 9. Droit applicable

La loi de Californie s'applique aux présentes. Les présentes Conditions constituent l'intégralité de l'accord entre vous et Mozilla relatif à Common Voice.
